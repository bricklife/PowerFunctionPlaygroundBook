//
//  PortId.swift
//  Book_Sources
//
//  Created by ooba on 07/08/2018.
//

import Foundation

public typealias PortId = UInt8
